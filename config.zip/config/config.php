<?php 

const RUTA_PRINCIAL = "https://jhonye.clasespiti.co/";
const RUTA_UPLOADS = "https://jhonye.clasespiti.co/Admin/Actions/";

 ?>