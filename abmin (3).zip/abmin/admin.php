<div>
    <center>
    <img src="<?php echo RUTA_PRINCIAL ?>/images/1.jpg" width="30%">
    </center>
</div>