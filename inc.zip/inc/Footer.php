
	<!-- Start Footer Section 
	<footer class="footer-section">
		<div class="container relative">
			</div>
				</div>
				<div class="col-lg-8">
					<div class="row links-wrap">
						<div class="col-6 col-sm-6 col-md-3">
							
						</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	-->
	<!-- End Footer Section -->
	<script src="js/bootstrap.bundle.min.js"></script>
	<script src="js/tiny-slider.js"></script>
	<script src="js/custom.js"></script>
</body>
</html>
